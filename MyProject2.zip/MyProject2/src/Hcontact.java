import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Hcontact")
public class Hcontact extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");

}
catch(Exception ae)
{}
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       
	String x=req.getParameter("t1");
	String y=req.getParameter("t2");
	String z=req.getParameter("t3");
	
	 
 try 
{

st=con.prepareStatement("insert into contact1 values(?,?,?)");
	st.setString(1,x);
	st.setString(2,y);
	st.setString(3,z);
	
	st.execute();
}
catch(Exception at)
{}
             res.sendRedirect("index.html");
	
            out.println("</body>");
            out.println("</html>");
              } 

}