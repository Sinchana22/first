import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/hlogin")
public class hlogin extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw=res.getWriter();		//to print on the browser the response
		res.setContentType("text/html");
		String email=req.getParameter("t2");
		String password=req.getParameter("t3");
						try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("select * from hregister where t2=? and t3=?");
		ps.setString(1,email);
		ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				res.sendRedirect("login.html");
			}
				res.sendRedirect("Book.html");
		}
				catch(Exception ae)
				{
				}
	}
				}