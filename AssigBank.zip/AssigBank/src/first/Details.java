package first;

public class Details 
{
		private int accno;
		private String firstName;
		private String phone;
		private String address;

		public Details() {
		}

		public Details(int accno, String firstName, String phone,
				String address) {
			this.accno = accno;
			this.firstName = firstName;
			this.phone = phone;
			this.address = address;
		}

		public int getAccno() {
			return accno;
		}

		public void setAccno(int accno) {
			this.accno = accno;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		@Override
		public String toString() {
			return "Person [accno=" + accno + ", firstName=" + firstName + ", phone=" + phone + ", address=" + address + "]";
		}

	}

