package utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	@SuppressWarnings("deprecation")
	public static Session getSession() {
		// empty configuration object
		Configuration cfg = new Configuration();
		// read the hibernate.cfg.xml
		cfg.configure();
		// obtain a session-factory object
		SessionFactory factory = cfg.buildSessionFactory();
		// get a new session 
		return factory.openSession();
	}

}
