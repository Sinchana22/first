package program;
import first.Details;
import utils.HibernateUtil;
import utils.KeyboardUtil;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

	public class bank {

		public static void main(String[] args) {

			int accno;
			String fname, phone, address;

			accno = KeyboardUtil.getInt("Enter accno: ");
			fname = KeyboardUtil.getString("Enter firstname: ");
			phone = KeyboardUtil.getString("Enter phone: ");
			address = KeyboardUtil.getString("Enter address: ");

			Details p1 = new Details(accno, fname, phone, address);
			
			Session session = HibernateUtil.getSession();
			Transaction tx = session.beginTransaction();
			try {
				session.save(p1);
				tx.commit();
				System.out.println("Data saved to db.");
			} catch (HibernateException e) {
				tx.rollback();
				System.out.println("There was an error while trying to save data.");
				System.out.println(e.getMessage());
			}
			session.close();
		}
	}
